<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="32x32_map_tile v1.1_0" tilewidth="32" tileheight="32" tilecount="170" columns="17">
 <image source="32x32_map_tile v1.1_0.png" width="568" height="329"/>
</tileset>
