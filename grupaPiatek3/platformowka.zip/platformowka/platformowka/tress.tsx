<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="tress" tilewidth="32" tileheight="32" tilecount="378" columns="27">
 <image source="tress.png" width="885" height="460"/>
</tileset>
