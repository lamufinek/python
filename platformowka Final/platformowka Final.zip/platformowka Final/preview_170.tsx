<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="preview_170" tilewidth="32" tileheight="32" tilecount="696" columns="29">
 <image source="preview_170.png" width="954" height="780"/>
</tileset>
