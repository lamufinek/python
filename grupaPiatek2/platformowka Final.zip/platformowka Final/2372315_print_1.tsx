<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.5.0" name="2372315_print_1" tilewidth="32" tileheight="32" tilecount="143" columns="11">
 <image source="2372315_print_1.png" width="373" height="420"/>
</tileset>
